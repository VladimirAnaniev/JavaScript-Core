import Entity from './Entity'
import Dog from './Dog'
import Person from './Person'
import Student from './Student'

result.Entity = Entity
result.Dog = Dog
result.Person = Person
result.Student = Student