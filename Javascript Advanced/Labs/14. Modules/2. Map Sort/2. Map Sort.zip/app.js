let mapSort = require('./map sort')

result.mapSort = mapSort