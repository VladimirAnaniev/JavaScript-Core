import Employee from './Employee'
import Branch from './Branch'

result.Employee = Employee
result.Branch = Branch