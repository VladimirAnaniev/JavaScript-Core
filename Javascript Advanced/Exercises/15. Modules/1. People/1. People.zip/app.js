import Employee from './Employee'
import Junior from './Junior'
import Manager from './Manager'
import Senior from './Senior'

result.Employee = Employee
result.Junior = Junior
result.Senior = Senior
result.Manager = Manager