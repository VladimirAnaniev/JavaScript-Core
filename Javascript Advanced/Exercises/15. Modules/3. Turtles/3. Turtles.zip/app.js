import Turtle from './Turtle'
import WaterTurtle from './WaterTurtle'
import EvkodianTurtle from './EvkodianTurtle'
import GalapagosTurtle from './GalapagosTurtle'
import NinjaTurtle from './NinjaTurtle'

result.Turtle = Turtle
result.WaterTurtle = WaterTurtle
result.EvkodianTurtle = EvkodianTurtle
result.GalapagosTurtle = GalapagosTurtle
result.NinjaTurtle = NinjaTurtle