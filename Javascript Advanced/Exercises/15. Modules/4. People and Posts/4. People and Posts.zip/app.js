import Person from './Person'
import Post from './Post'

result.Person = Person
result.Post = Post